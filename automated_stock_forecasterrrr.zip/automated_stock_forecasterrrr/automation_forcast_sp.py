import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import streamlit as st

from sklearn.model_selection import TimeSeriesSplit

from sklearn.linear_model import (
    LinearRegression,
    Ridge
)

from sklearn.metrics import (
    mean_absolute_error,
    mean_squared_error,
    r2_score
)

st.set_page_config(
    page_title="Stock Price Forecaster",
    page_icon="📈",
    layout="wide"
)


st.title("📈 Stock Price Forecaster")

st.write(
    "Upload historical stock data and get a next-day "
    "closing price prediction using Machine Learning."
)


# UPLOAD DATA

uploaded_file = st.file_uploader(
    "Upload your stock CSV file",
    type=["csv"]
)


if uploaded_file is not None:

    # 2. LOAD DATA
    

    df = pd.read_csv(
        uploaded_file
    )

    st.subheader("Data Loaded")

    st.write(
        "Rows:",
        df.shape[0]
    )

    st.write(
        "Columns:",
        df.shape[1]
    )

    st.dataframe(
        df.head()
    )


    # 3. STANDARDIZE COLUMN NAMES
    

    df.columns = [
        str(column).strip()
        for column in df.columns
    ]


   
    # Find required columns
   

    column_names = {
        column.lower(): column
        for column in df.columns
    }


    required_columns = [
        "date",
        "open",
        "high",
        "low",
        "close",
        "volume"
    ]


    missing_columns = []

    for column in required_columns:

        if column not in column_names:

            missing_columns.append(
                column
            )


    if len(missing_columns) > 0:

        st.error(
            "The following required columns are missing: "
            + ", ".join(missing_columns)
        )

        st.info(
            "Your CSV should contain: "
            "Date, Open, High, Low, Close and Volume."
        )

        st.stop()


    # 4. RENAME COLUMNS
   

    df = df.rename(
        columns={
            column_names["date"]: "Date",
            column_names["open"]: "Open",
            column_names["high"]: "High",
            column_names["low"]: "Low",
            column_names["close"]: "Close",
            column_names["volume"]: "Volume"
        }
    )


    
    # 5. ADJ CLOSE
    

    # Some datasets have Adj Close
    # Some datasets don't

    if "Adj Close" not in df.columns:

        df["Adj Close"] = df["Close"]


    
    # 6. DATA CLEANING
    

    st.subheader("Data Cleaning")


    df["Date"] = pd.to_datetime(
        df["Date"],
        errors="coerce"
    )


    # Convert numerical columns

    numeric_columns = [
        "Open",
        "High",
        "Low",
        "Close",
        "Adj Close",
        "Volume"
    ]


    for column in numeric_columns:

        df[column] = pd.to_numeric(
            df[column],
            errors="coerce"
        )


    # Sort by date

    df = df.sort_values(
        "Date"
    )


    # Remove duplicate dates

    duplicate_dates = df["Date"].duplicated().sum()

    df = df.drop_duplicates(
        subset=["Date"],
        keep="last"
    )


    # Remove missing values

    missing_before = df[
        numeric_columns
    ].isnull().sum().sum()


    df = df.dropna(
        subset=numeric_columns
    )


    # Remove invalid volume

    df = df[
        df["Volume"] >= 0
    ]


    # 7. DATA VALIDATION
   

    high_open_errors = (
        df["High"] < df["Open"]
    ).sum()


    high_close_errors = (
        df["High"] < df["Close"]
    ).sum()


    low_open_errors = (
        df["Low"] > df["Open"]
    ).sum()


    low_close_errors = (
        df["Low"] > df["Close"]
    ).sum()


    date_order = (
        df["Date"].is_monotonic_increasing
    )


    # 8. DATA QUALITY REPORT
    

    col1, col2, col3, col4 = st.columns(4)


    col1.metric(
        "Rows",
        len(df)
    )

    col2.metric(
        "Duplicates Removed",
        duplicate_dates
    )

    col3.metric(
        "Missing Values Removed",
        missing_before
    )

    col4.metric(
        "Date Order",
        "Correct" if date_order else "Check"
    )


    st.write(
        "Date range:",
        df["Date"].min(),
        "to",
        df["Date"].max()
    )


    st.write(
        "High < Open:",
        high_open_errors
    )

    st.write(
        "High < Close:",
        high_close_errors
    )

    st.write(
        "Low > Open:",
        low_open_errors
    )

    st.write(
        "Low > Close:",
        low_close_errors
    )


    # 9. EDA
    

    st.subheader("Exploratory Data Analysis")


    # Closing Price
    

    figure = plt.figure(
        figsize=(12, 5)
    )

    plt.plot(
        df["Date"],
        df["Close"]
    )

    plt.title(
        "Closing Price"
    )

    plt.xlabel(
        "Date"
    )

    plt.ylabel(
        "Price"
    )

    plt.xticks(
        rotation=45
    )

    plt.tight_layout()

    st.pyplot(
        figure
    )

    plt.close()


   
    # Open vs Close
    

    figure = plt.figure(
        figsize=(12, 5)
    )

    plt.plot(
        df["Date"],
        df["Open"],
        label="Open"
    )

    plt.plot(
        df["Date"],
        df["Close"],
        label="Close"
    )

    plt.title(
        "Open vs Close"
    )

    plt.xlabel(
        "Date"
    )

    plt.ylabel(
        "Price"
    )

    plt.legend()

    plt.xticks(
        rotation=45
    )

    plt.tight_layout()

    st.pyplot(
        figure
    )

    plt.close()


    
    # High vs Low
    

    figure = plt.figure(
        figsize=(12, 5)
    )

    plt.plot(
        df["Date"],
        df["High"],
        label="High"
    )

    plt.plot(
        df["Date"],
        df["Low"],
        label="Low"
    )

    plt.title(
        "High vs Low"
    )

    plt.xlabel(
        "Date"
    )

    plt.ylabel(
        "Price"
    )

    plt.legend()

    plt.xticks(
        rotation=45
    )

    plt.tight_layout()

    st.pyplot(
        figure
    )

    plt.close()


    # Volume
    

    figure = plt.figure(
        figsize=(12, 5)
    )

    plt.plot(
        df["Date"],
        df["Volume"]
    )

    plt.title(
        "Trading Volume"
    )

    plt.xlabel(
        "Date"
    )

    plt.ylabel(
        "Volume"
    )

    plt.xticks(
        rotation=45
    )

    plt.tight_layout()

    st.pyplot(
        figure
    )

    plt.close()


   
    # Closing Price Distribution
    

    figure = plt.figure(
        figsize=(10, 5)
    )

    plt.hist(
        df["Close"],
        bins=50
    )

    plt.title(
        "Distribution of Closing Price"
    )

    plt.xlabel(
        "Closing Price"
    )

    plt.ylabel(
        "Frequency"
    )

    plt.tight_layout()

    st.pyplot(
        figure
    )

    plt.close()


    
    # Boxplot
  

    figure = plt.figure(
        figsize=(8, 5)
    )

    plt.boxplot(
        df["Close"]
    )

    plt.title(
        "Closing Price Boxplot"
    )

    plt.ylabel(
        "Closing Price"
    )

    st.pyplot(
        figure
    )

    plt.close()


   
    # 10. DAILY RETURN
  

    df["Daily_Return"] = (
        df["Close"].pct_change()
    )


    
    # Daily Return Graph
    

    figure = plt.figure(
        figsize=(12, 5)
    )

    plt.plot(
        df["Date"],
        df["Daily_Return"]
    )

    plt.title(
        "Daily Return"
    )

    plt.xlabel(
        "Date"
    )

    plt.ylabel(
        "Daily Return"
    )

    plt.xticks(
        rotation=45
    )

    plt.tight_layout()

    st.pyplot(
        figure
    )

    plt.close()


    
    # Return Distribution
  

    figure = plt.figure(
        figsize=(10, 5)
    )

    plt.hist(
        df["Daily_Return"].dropna(),
        bins=50
    )

    plt.title(
        "Distribution of Daily Return"
    )

    plt.xlabel(
        "Daily Return"
    )

    plt.ylabel(
        "Frequency"
    )

    plt.tight_layout()

    st.pyplot(
        figure
    )

    plt.close()


    
    # 11. CORRELATION
   

    st.subheader(
        "Correlation Analysis"
    )


    correlation = df[
        [
            "Open",
            "High",
            "Low",
            "Close",
            "Volume"
        ]
    ].corr()


    st.dataframe(
        correlation
    )


    # 12. FEATURE ENGINEERING
    

    st.subheader(
        "Feature Engineering"
    )


    # TARGET
    

    # Tomorrow's closing price

    df["Target"] = (
        df["Close"].shift(-1)
    )


   
    # LAG FEATURES
   

    df["Close_Lag1"] = (
        df["Close"].shift(1)
    )

    df["Close_Lag2"] = (
        df["Close"].shift(2)
    )

    df["Close_Lag3"] = (
        df["Close"].shift(3)
    )

    df["Close_Lag4"] = (
        df["Close"].shift(4)
    )

    df["Close_Lag5"] = (
        df["Close"].shift(5)
    )


    
    # MOVING AVERAGES
    

    df["MA_5"] = (
        df["Close"].rolling(5).mean()
    )

    df["MA_10"] = (
        df["Close"].rolling(10).mean()
    )

    df["MA_20"] = (
        df["Close"].rolling(20).mean()
    )

    df["MA_50"] = (
        df["Close"].rolling(50).mean()
    )


    # RETURNS
    

    df["Return_3D"] = (
        df["Close"].pct_change(3)
    )

    df["Return_5D"] = (
        df["Close"].pct_change(5)
    )

    df["Return_10D"] = (
        df["Close"].pct_change(10)
    )


    # VOLATILITY
   

    df["Volatility_5"] = (
        df["Daily_Return"].rolling(5).std()
    )

    df["Volatility_10"] = (
        df["Daily_Return"].rolling(10).std()
    )

    df["Volatility_20"] = (
        df["Daily_Return"].rolling(20).std()
    )


    
    # PRICE FEATURES
   

    df["Price_Range"] = (
        df["High"] - df["Low"]
    )

    df["Open_Close_Diff"] = (
        df["Close"] - df["Open"]
    )


    df["High_Low_Ratio"] = (
        df["High"] / df["Low"]
    )


    df["Open_Close_Ratio"] = (
        df["Open"] / df["Close"]
    )


    # MOVING AVERAGE RELATIONSHIPS
    

    df["Close_vs_MA5"] = (
        df["Close"] / df["MA_5"]
    )

    df["Close_vs_MA20"] = (
        df["Close"] / df["MA_20"]
    )

    df["Close_vs_MA50"] = (
        df["Close"] / df["MA_50"]
    )


    df["MA_5_MA_20_Ratio"] = (
        df["MA_5"] / df["MA_20"]
    )

    df["MA_20_MA_50_Ratio"] = (
        df["MA_20"] / df["MA_50"]
    )


   
    # VOLUME FEATURES
   

    df["Volume_MA_5"] = (
        df["Volume"].rolling(5).mean()
    )

    df["Volume_MA_20"] = (
        df["Volume"].rolling(20).mean()
    )


    df["Volume_Ratio"] = (
        df["Volume"] /
        df["Volume_MA_5"]
    )


    df["Volume_vs_MA20"] = (
        df["Volume"] /
        df["Volume_MA_20"]
    )


  
    # DAY OF WEEK
    

    df["Day_of_Week"] = (
        df["Date"].dt.dayofweek
    )


    
    # 13. KEEP LAST ROW FOR PREDICTION
   

    # The last row does not have a Target
    # because tomorrow's actual price is unknown.

    prediction_row = df.iloc[[-1]].copy()


  
    # 14. REMOVE MISSING VALUES FOR TRAINING
    

    df_model = df.dropna()


    st.write(
        "Rows available for modelling:",
        len(df_model)
    )


   
    # 15. CREATE X AND y
    

    # Target = tomorrow's closing price

    y = df_model["Target"]


    # Features

    X = df_model.drop(
        columns=[
            "Target",
            "Date"
        ]
    )


   
    # 16. TRAIN / TEST SPLIT
   

    split_index = int(
        len(df_model) * 0.80
    )


    X_train = X.iloc[:split_index]

    X_test = X.iloc[split_index:]


    y_train = y.iloc[:split_index]

    y_test = y.iloc[split_index:]


    # 17. BASELINE
   

    # Tomorrow's price = today's closing price

    baseline_pred = X_test["Close"]


    baseline_mae = mean_absolute_error(
        y_test,
        baseline_pred
    )


    baseline_rmse = (
        mean_squared_error(
            y_test,
            baseline_pred
        ) ** 0.5
    )


    baseline_r2 = r2_score(
        y_test,
        baseline_pred
    )


   
    # 18. LINEAR REGRESSION
    

    linear_model = LinearRegression()


    linear_model.fit(
        X_train,
        y_train
    )


    linear_pred = linear_model.predict(
        X_test
    )


    linear_mae = mean_absolute_error(
        y_test,
        linear_pred
    )


    linear_rmse = (
        mean_squared_error(
            y_test,
            linear_pred
        ) ** 0.5
    )


    linear_r2 = r2_score(
        y_test,
        linear_pred
    )


   
    # 19. RIDGE
    

    ridge_model = Ridge(
        alpha=1.0
    )


    ridge_model.fit(
        X_train,
        y_train
    )


    ridge_pred = ridge_model.predict(
        X_test
    )


    ridge_mae = mean_absolute_error(
        y_test,
        ridge_pred
    )


    ridge_rmse = (
        mean_squared_error(
            y_test,
            ridge_pred
        ) ** 0.5
    )


    ridge_r2 = r2_score(
        y_test,
        ridge_pred
    )


   
    # 20. MODEL COMPARISON
   

    results = pd.DataFrame({

        "Model": [
            "Baseline",
            "Linear Regression",
            "Ridge"
        ],

        "MAE": [
            baseline_mae,
            linear_mae,
            ridge_mae
        ],

        "RMSE": [
            baseline_rmse,
            linear_rmse,
            ridge_rmse
        ],

        "R2": [
            baseline_r2,
            linear_r2,
            ridge_r2
        ]

    })


    st.subheader(
        "Model Comparison"
    )


    st.dataframe(
        results
    )


   
    # 21. TIME SERIES CROSS VALIDATION
    

    st.subheader(
        "Time Series Cross Validation"
    )


    tscv = TimeSeriesSplit(
        n_splits=5
    )


    linear_cv_scores = []

    ridge_cv_scores = []


    for fold, (
        train_index,
        test_index
    ) in enumerate(
        tscv.split(X),
        start=1
    ):

        X_cv_train = X.iloc[
            train_index
        ]

        X_cv_test = X.iloc[
            test_index
        ]


        y_cv_train = y.iloc[
            train_index
        ]

        y_cv_test = y.iloc[
            test_index
        ]


        # Linear Regression
        

        linear_cv_model = LinearRegression()


        linear_cv_model.fit(
            X_cv_train,
            y_cv_train
        )


        linear_cv_prediction = (
            linear_cv_model.predict(
                X_cv_test
            )
        )


        linear_cv_mae = (
            mean_absolute_error(
                y_cv_test,
                linear_cv_prediction
            )
        )


        linear_cv_scores.append(
            linear_cv_mae
        )


        
        # Ridge
        

        ridge_cv_model = Ridge(
            alpha=1.0
        )


        ridge_cv_model.fit(
            X_cv_train,
            y_cv_train
        )


        ridge_cv_prediction = (
            ridge_cv_model.predict(
                X_cv_test
            )
        )


        ridge_cv_mae = (
            mean_absolute_error(
                y_cv_test,
                ridge_cv_prediction
            )
        )


        ridge_cv_scores.append(
            ridge_cv_mae
        )


        print(
            "Fold:",
            fold
        )


    # 22. CV AVERAGE
    

    linear_average_mae = (
        sum(linear_cv_scores)
        /
        len(linear_cv_scores)
    )


    ridge_average_mae = (
        sum(ridge_cv_scores)
        /
        len(ridge_cv_scores)
    )


    cv_results = pd.DataFrame({

        "Model": [
            "Linear Regression",
            "Ridge"
        ],

        "Fold_1_MAE": [
            linear_cv_scores[0],
            ridge_cv_scores[0]
        ],

        "Fold_2_MAE": [
            linear_cv_scores[1],
            ridge_cv_scores[1]
        ],

        "Fold_3_MAE": [
            linear_cv_scores[2],
            ridge_cv_scores[2]
        ],

        "Fold_4_MAE": [
            linear_cv_scores[3],
            ridge_cv_scores[3]
        ],

        "Fold_5_MAE": [
            linear_cv_scores[4],
            ridge_cv_scores[4]
        ],

        "Average_MAE": [
            linear_average_mae,
            ridge_average_mae
        ]

    })


    st.write(
        "Time Series Cross Validation Results"
    )


    st.dataframe(
        cv_results
    )


    # 23. SELECT BEST MODEL
   

    if ridge_average_mae < linear_average_mae:

        best_model_name = "Ridge"

        best_model = Ridge(
            alpha=1.0
        )

    else:

        best_model_name = (
            "Linear Regression"
        )

        best_model = LinearRegression()


    st.success(
        "Selected Model: "
        + best_model_name
    )


  
    # 24. TRAIN FINAL MODEL
   

    # Train the selected model
    # on all historical training data

    best_model.fit(
        X,
        y
    )


   
    # 25. PREPARE LATEST DATA
    

    latest_features = (
        prediction_row.drop(
            columns=[
                "Target",
                "Date"
            ]
        )
    )


    # Make sure latest features
    # have no missing values

    if latest_features.isnull().sum().sum() > 0:

        st.error(
            "There are not enough historical rows "
            "to calculate all required features."
        )

        st.stop()


    # 26. PREDICT TOMORROW
   

    tomorrow_prediction = (
        best_model.predict(
            latest_features
        )[0]
    )


    latest_close = (
        prediction_row["Close"].iloc[0]
    )


    prediction_date = (
        prediction_row["Date"].iloc[0]
    )


   
    # 27. PRICE CHANGE
    

    predicted_change = (
        tomorrow_prediction
        -
        latest_close
    )


    predicted_change_percent = (
        predicted_change
        /
        latest_close
        *
        100
    )


    # 28. FINAL PREDICTION
   

    st.subheader(
        "🔮 Next Day Forecast"
    )


    col1, col2, col3 = st.columns(3)


    col1.metric(
        "Latest Closing Price",
        f"{latest_close:.2f}"
    )


    col2.metric(
        "Predicted Next Closing Price",
        f"{tomorrow_prediction:.2f}"
    )


    col3.metric(
        "Predicted Change",
        f"{predicted_change_percent:.2f}%"
    )


    st.write(
        "Last available trading date:",
        prediction_date
    )


    st.write(
        "Selected model:",
        best_model_name
    )


    # 29. ACTUAL VS PREDICTED
   

    comparison = pd.DataFrame({

        "Actual": y_test.values,

        "Baseline": baseline_pred.values,

        "Linear_Regression": linear_pred,

        "Ridge": ridge_pred

    })


    st.subheader(
        "Actual vs Predicted"
    )


    st.dataframe(
        comparison.head(10)
    )


    
    # 30. PREDICTION GRAPH
    

    figure = plt.figure(
        figsize=(12, 5)
    )


    plt.plot(
        y_test.values,
        label="Actual"
    )


    plt.plot(
        baseline_pred.values,
        label="Baseline"
    )


    plt.plot(
        ridge_pred,
        label="Ridge"
    )


    plt.title(
        "Actual vs Predicted Stock Price"
    )


    plt.xlabel(
        "Test Observations"
    )


    plt.ylabel(
        "Stock Price"
    )


    plt.legend()


    plt.tight_layout()


    st.pyplot(
        figure
    )


    plt.close()


    
    # 31. FEATURE CORRELATION
   

    st.subheader(
        "Feature Correlation with Target"
    )


    numeric_df = df_model.select_dtypes(
        include="number"
    )


    target_correlation = (
        numeric_df.corr()["Target"]
        .sort_values(
            ascending=False
        )
    )


    st.dataframe(
        target_correlation
    )


    
    # 32. FINAL SUMMARY
    

    st.subheader(
        "📊 Final Summary"
    )


    st.write(
        "Total historical observations:",
        len(df)
    )


    st.write(
        "Observations used for modelling:",
        len(df_model)
    )


    st.write(
        "Linear Regression CV MAE:",
        round(
            linear_average_mae,
            4
        )
    )


    st.write(
        "Ridge CV MAE:",
        round(
            ridge_average_mae,
            4
        )
    )


    st.write(
        "Final selected model:",
        best_model_name
    )


    st.write(
        "Latest closing price:",
        round(
            latest_close,
            2
        )
    )


    st.write(
        "Predicted next closing price:",
        round(
            tomorrow_prediction,
            2
        )
    )


    st.info(
        "This prediction is a machine-learning estimate "
        "based on historical market data. It should not "
        "be treated as financial advice."
    )