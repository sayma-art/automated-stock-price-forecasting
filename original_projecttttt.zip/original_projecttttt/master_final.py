import yfinance as yf

data = yf.download(
    "HDFCBANK.NS",
    start = "2016-01-01",
    end = "2026-08-01",
    auto_adjust = False
)
print(data.head())
print(data.shape)
print(data.columns)
data.to_csv("data/HDFCBANK_raw.csv")
print("Data saved successfully")

#Data Cleaning
import pandas as pd
df = pd.read_csv("data/HDFCBANK_raw.csv",
                 header = [0,1],
                 index_col = 0,
                 )
df.columns = df.columns.get_level_values(0)
df.index = pd.to_datetime(df.index)
df = df.reset_index()
df = df[
    ["Date",
     "Open",
     "High",
     "Low",
     "Close",
     "Adj Close",
     "Volume"
    

    ]
]
df = df.sort_values("Date")  
print(df.head())
print(df.shape)
print(df.describe())
print(df.isnull().sum())
print(df.duplicated().sum())
print(df["Date"].min(),"to",df["Date"].max())
print(df.info())

print((df[["Open","High","Low","Close"]]).sum())
print((df["High"]<df["Open"]).sum())
print((df["High"]<df["Close"]).sum())
print((df["Low"]>df["Open"]).sum())
print((df["Low"]>df["Close"]).sum())
#checking volume
print((df["Volume"]<0).sum())
#date order
print(df["Date"].is_monotonic_increasing)
df.to_csv("data/HDFCBANK_clean.csv",index=False)

# EDA 
import pandas as pd
import matplotlib.pyplot as plt
df = pd.read_csv("data/HDFCBANK_clean.csv")
#converting date into datetimed
plt.figure(figsize=(12,6))
plt.plot(df["Date"],df["Close"])
plt.title("HDFC Bank Closing Price")
plt.xlabel("Date")
plt.ylabel("Price")
plt.show()

#open Vs close
plt.figure(figsize=(12,6))
plt.plot(df["Date"],df["Open"],label="Open")
plt.plot(df["Date"],df["Close"],label="Close")
plt.title("HDFC Bank Open Vs Close")
plt.xlabel("Date")
plt.ylabel("Price")
plt.legend()
plt.show()

#high Vs low
plt.figure(figsize=(12,6))
plt.plot(df["Date"],df["High"],label="High")
plt.plot(df["Date"],df["Low"],label="Low")
plt.title("HDFC Bank High vs Low")
plt.xlabel("Date")
plt.ylabel("price")
plt.legend()
plt.show()

#volume Graph
plt.figure(figsize=(12,6))
plt.plot(df["Date"],df["Volume"])
plt.title("HDFC Bank Trading Volume")
plt.xlabel("Date")
plt.ylabel("Volume")
plt.show()


#distribution of closing price
plt.figure(figsize=(10,6))
plt.hist(df["Close"],bins=50)
plt.title("Distribution of HDFC Bank Closing Price")
plt.xlabel("Closing Price")
plt.ylabel("Frequency")       
plt.show()         

#Boxplot 
plt.figure(figsize=(8,6))
plt.boxplot(df["Close"])
plt.title("Closing Price Boxplot")
plt.ylabel("Closing Price")
plt.show()

#Daily Return
df["Daily Return"]=df["Close"]

plt.figure(figsize=(12,6))
plt.plot(df["Date"],df["Daily Return"])
plt.title("HDFC Bank Daily Return")
plt.xlabel("Date")
plt.ylabel("Daily Return")
plt.show()

# Distribution of Return
plt.figure(figsize=(10,6))
plt.hist(df["Daily Return"].dropna(),bins=50)
plt.title("HDFC Bank Dist of return")
plt.xlabel("Daily Return")
plt.ylabel("Frequency")
plt.show()

#Correlation
print(df[[
    "Open",
    "High",
    "Low",
    "Close",
    "Volume"
]].corr())

#Heatmap
import seaborn as sns
correlation = df[
    ["Open", "High", "Low", "Close", "Volume"]
].corr()
plt.figure(figsize=(8,6))
sns.heatmap(
    correlation,
    annot=True
)
plt.title("HDFC Bank Correlation Matrix")
plt.show()

df.to_csv("data/HDFC_eda.csv",
          index=False)

# Feature Engineering

import pandas as pd
df = pd.read_csv("data/HDFCBANK_clean.csv")

df["Date"] = pd.to_datetime(df["Date"])


# Tomorrow's closing price
df["Target"] = df["Close"].shift(-1)

#  LAG FEATURES
df["Close_Lag1"] = df["Close"].shift(1)
df["Close_Lag2"] = df["Close"].shift(2)
df["Close_Lag3"] = df["Close"].shift(3)
df["Close_Lag4"] = df["Close"].shift(4)
df["Close_Lag5"] = df["Close"].shift(5)

#  MOVING AVERAGES
df["MA_5"] = df["Close"].rolling(5).mean()
df["MA_10"] = df["Close"].rolling(10).mean()
df["MA_20"] = df["Close"].rolling(20).mean()

#  DAILY RETURN
df["Daily_Return"] = df["Close"].pct_change()

#  VOLATILITY
df["Volatility_5"] = df["Daily_Return"].rolling(5).std()
df["Volatility_10"] = df["Daily_Return"].rolling(10).std()

df["Price_Range"] = df["High"] - df["Low"]

df["Open_Close_Diff"] = df["Close"] - df["Open"]

df["Volume_MA_5"] = df["Volume"].rolling(5).mean()

df["Volume_Ratio"] = (
    df["Volume"] / df["Volume_MA_5"]
)

df["Day_of_Week"] = df["Date"].dt.dayofweek

df = df.dropna()

df.to_csv(
    "data/HDFCBANK_features.csv",
    index=False
)

print(df.shape)
print(df.columns.tolist())
print(df.head())


# Train/Test Split


import pandas as pd
df = pd.read_csv("data/HDFCBANK_features.csv")

df["Date"] = pd.to_datetime(df["Date"])
# CREATE X AND y
# Target = tomorrow's closing price
y = df["Target"]

# Features
X = df.drop(columns=["Target", "Date"])
# TRAIN / TEST SPLIT

split_index = int(len(df) * 0.80)

X_train = X.iloc[:split_index]
X_test = X.iloc[split_index:]

y_train = y.iloc[:split_index]
y_test = y.iloc[split_index:]

#  CHECK DATA

print("Total rows:", len(df))
print("Split index:", split_index)

print("y shape:", y.shape)

print("Testing X:", X_test.shape)

print("Testing y:", y_test.shape)

#  CHECK DATES

print(df["Date"].iloc[0])
print(df["Date"].iloc[split_index - 1])
print(df["Date"].iloc[split_index])
print(df["Date"].iloc[-1])

#save
X_train.to_csv("data/X_train.csv", index=False)
X_test.to_csv("data/X_test.csv", index=False)

y_train.to_csv("data/y_train.csv", index=False)
y_test.to_csv("data/y_test.csv", index=False)

# Train Model

import  pandas as pd

from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor

x_train = pd.read_csv("data/X_train.csv") 
y_train = pd.read_csv("data/y_train.csv").squeeze()

print("x_train.shape:", x_train.shape)
print("y_train.shape:", y_train.shape)
#ML model
linear_model = LinearRegression()
linear_model.fit(
    x_train,
    y_train
)

#RF
rf_model = RandomForestRegressor(
    n_estimators=100,
    random_state=42,
    n_jobs=-1
)
rf_model.fit(
    x_train,
    y_train
)

#Prediction
linear_prediction = linear_model.predict(
    x_train
)
rf_prediction = rf_model.predict(
    x_train
)
print(linear_prediction[:5])
print(rf_prediction[:5])

#Evaluation

import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor

from sklearn.metrics import(
    mean_absolute_error,
    mean_squared_error,
    r2_score
)
X_train = pd.read_csv("data/X_train.csv")
X_test = pd.read_csv("data/X_test.csv")

y_train = pd.read_csv("data/y_train.csv").squeeze()
y_test = pd.read_csv("data/y_test.csv").squeeze()

linear_model = LinearRegression()
linear_model.fit(
    X_train,
    y_train
)
linear_pred = linear_model.predict(
    X_test
)
rf_model = RandomForestRegressor(
    n_estimators=100,
    random_state=42,
    n_jobs=-1
)

rf_model.fit(
    X_train,
    y_train
)
rf_pred = rf_model.predict(
    X_test
)

#baseline
baseline_pred = X_test["Close"]


# COMPARE ACTUAL VS PREDICTED


comparison = pd.DataFrame({
    "Actual": y_test.values,
    "Baseline": baseline_pred.values,
    "Linear_Regression": linear_pred,
    "Random_Forest": rf_pred
})

print(comparison.head(10))

baseline_mae = mean_absolute_error(
    y_test,
    baseline_pred
)
baseline_rmse = mean_squared_error(
    y_test,
    baseline_pred
)**0.5

baseline_r2 = r2_score(
    y_test,
    baseline_pred
)
#linear regression
linear_mae = mean_absolute_error(
    y_test,
    linear_pred
)
linear_rmse = mean_squared_error(
    y_test,
    linear_pred
)**0.5
linear_r2 = r2_score(
    y_test,
    linear_pred
)

#Random Forest
rf_mae = mean_absolute_error(
    y_test,
    rf_pred
)
rf_rmse = mean_squared_error(
    y_test,
    rf_pred
)**0.5
rf_r2 = r2_score(
    y_test,
    rf_pred
)

#result
print("MAE:",baseline_mae)
print("RMSE:",baseline_rmse)
print("R2:",baseline_r2)

#linear regression
print("MAE:",linear_mae)
print("RMSE:",linear_rmse)
print("R2:",linear_r2)

#RF
print("MAE:",rf_mae)
print("RMSE:",rf_rmse)
print("R2:",rf_r2)

# Cross Validation

import pandas as pd 
from sklearn.model_selection import TimeSeriesSplit
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error

df = pd.read_csv("data/HDFCBANK_features.csv")

X = df.drop(
    columns=["Target","Date"]
)
y = df["Target"]
tscv = TimeSeriesSplit(
    n_splits=5
)

mae_scores = []

for fold, (train_index,test_index)in enumerate(tscv.split(X)):
    X_train = X.iloc[train_index]
    X_test = X.iloc[test_index]

    y_train = y.iloc[train_index]
    y_test = y.iloc[test_index]

    print("Training observations:", len(X_train))
    print("Testing observations:", len(X_test))

    model = LinearRegression()

    model.fit(X_train, y_train)

    prediction = model.predict(X_test)

    mae = mean_absolute_error(y_test, prediction)

    mae_scores.append(mae)

    print("MAE:", mae)



 #AVERAGE MAE
average_mae = sum(mae_scores) / len(mae_scores)

print("MAE scores:", mae_scores)

print("Average MAE:", average_mae)

# RIDGE MODEL

import pandas as pd

from sklearn.linear_model import Ridge

from sklearn.metrics import (
    mean_absolute_error,
    mean_squared_error,
    r2_score
)


X_train = pd.read_csv(
    "data/X_train.csv"
)

X_test = pd.read_csv(
    "data/X_test.csv"
)

y_train = pd.read_csv(
    "data/y_train.csv"
).squeeze()

y_test = pd.read_csv(
    "data/y_test.csv"
).squeeze()


model = Ridge(
    alpha=1.0
)


model.fit(
    X_train,
    y_train
)

prediction = model.predict(
    X_test
)


mae = mean_absolute_error(
    y_test,
    prediction
)


rmse = (
    mean_squared_error(
        y_test,
        prediction
    ) ** 0.5
)


r2 = r2_score(
    y_test,
    prediction
)


print(
    "Final Ridge Regression Results"
)

print(
    "MAE:",
    mae
)

print(
    "RMSE:",
    rmse
)

print(
    "R2:",
    r2
)



# ACTUAL VS PREDICTED

comparison = pd.DataFrame({

    "Actual": y_test.values,

    "Predicted": prediction

})


print(
    comparison.head(10)
)