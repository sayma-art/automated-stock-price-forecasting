import pandas as pd
df = pd.read_csv("data/HDFCBANK_clean.csv")

df["Date"] = pd.to_datetime(df["Date"])


# Tomorrow's closing price
df["Target"] = df["Close"].shift(-1)

#  LAG FEATURES
df["Close_Lag1"] = df["Close"].shift(1)
df["Close_Lag2"] = df["Close"].shift(2)
df["Close_Lag3"] = df["Close"].shift(3)
df["Close_Lag4"] = df["Close"].shift(4)
df["Close_Lag5"] = df["Close"].shift(5)

#  MOVING AVERAGES
df["MA_5"] = df["Close"].rolling(5).mean()
df["MA_10"] = df["Close"].rolling(10).mean()
df["MA_20"] = df["Close"].rolling(20).mean()

#  DAILY RETURN
df["Daily_Return"] = df["Close"].pct_change()

#  VOLATILITY
df["Volatility_5"] = df["Daily_Return"].rolling(5).std()
df["Volatility_10"] = df["Daily_Return"].rolling(10).std()

df["Price_Range"] = df["High"] - df["Low"]

df["Open_Close_Diff"] = df["Close"] - df["Open"]

df["Volume_MA_5"] = df["Volume"].rolling(5).mean()

df["Volume_Ratio"] = (
    df["Volume"] / df["Volume_MA_5"]
)

df["Day_of_Week"] = df["Date"].dt.dayofweek

df = df.dropna()

df.to_csv(
    "data/HDFCBANK_features.csv",
    index=False
)

print(df.shape)
print(df.columns.tolist())
print(df.head())