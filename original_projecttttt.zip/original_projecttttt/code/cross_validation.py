import pandas as pd 
from sklearn.model_selection import TimeSeriesSplit
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error

df = pd.read_csv("data/HDFCBANK_features.csv")

X = df.drop(
    columns=["Target","Date"]
)
y = df["Target"]
tscv = TimeSeriesSplit(
    n_splits=5
)

mae_scores = []

for fold, (train_index,test_index)in enumerate(tscv.split(X)):
    X_train = X.iloc[train_index]
    X_test = X.iloc[test_index]

    y_train = y.iloc[train_index]
    y_test = y.iloc[test_index]

    print("Training observations:", len(X_train))
    print("Testing observations:", len(X_test))

    model = LinearRegression()

    model.fit(X_train, y_train)

    prediction = model.predict(X_test)

    mae = mean_absolute_error(y_test, prediction)

    mae_scores.append(mae)

    print("MAE:", mae)



 #AVERAGE MAE
average_mae = sum(mae_scores) / len(mae_scores)

print("MAE scores:", mae_scores)

print("Average MAE:", average_mae)