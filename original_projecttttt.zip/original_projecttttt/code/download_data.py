import yfinance as yf

data = yf.download(
    "HDFCBANK.NS",
    start = "2016-01-01",
    end = "2026-08-01",
    auto_adjust = False
)
print(data.head())
print(data.shape)
print(data.columns)
data.to_csv("data/HDFCBANK_raw.csv")
print("Data saved successfully")