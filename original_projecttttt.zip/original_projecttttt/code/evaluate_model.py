import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor

from sklearn.metrics import(
    mean_absolute_error,
    mean_squared_error,
    r2_score
)
X_train = pd.read_csv("data/X_train.csv")
X_test = pd.read_csv("data/X_test.csv")

y_train = pd.read_csv("data/y_train.csv").squeeze()
y_test = pd.read_csv("data/y_test.csv").squeeze()

linear_model = LinearRegression()
linear_model.fit(
    X_train,
    y_train
)
linear_pred = linear_model.predict(
    X_test
)
rf_model = RandomForestRegressor(
    n_estimators=100,
    random_state=42,
    n_jobs=-1
)

rf_model.fit(
    X_train,
    y_train
)
rf_pred = rf_model.predict(
    X_test
)

#baseline
baseline_pred = X_test["Close"]


# COMPARE ACTUAL VS PREDICTED


comparison = pd.DataFrame({
    "Actual": y_test.values,
    "Baseline": baseline_pred.values,
    "Linear_Regression": linear_pred,
    "Random_Forest": rf_pred
})

print(comparison.head(10))

baseline_mae = mean_absolute_error(
    y_test,
    baseline_pred
)
baseline_rmse = mean_squared_error(
    y_test,
    baseline_pred
)**0.5

baseline_r2 = r2_score(
    y_test,
    baseline_pred
)
#linear regression
linear_mae = mean_absolute_error(
    y_test,
    linear_pred
)
linear_rmse = mean_squared_error(
    y_test,
    linear_pred
)**0.5
linear_r2 = r2_score(
    y_test,
    linear_pred
)

#Random Forest
rf_mae = mean_absolute_error(
    y_test,
    rf_pred
)
rf_rmse = mean_squared_error(
    y_test,
    rf_pred
)**0.5
rf_r2 = r2_score(
    y_test,
    rf_pred
)

#result
print("MAE:",baseline_mae)
print("RMSE:",baseline_rmse)
print("R2:",baseline_r2)

#linear regression
print("MAE:",linear_mae)
print("RMSE:",linear_rmse)
print("R2:",linear_r2)

#RF
print("MAE:",rf_mae)
print("RMSE:",rf_rmse)
print("R2:",rf_r2)