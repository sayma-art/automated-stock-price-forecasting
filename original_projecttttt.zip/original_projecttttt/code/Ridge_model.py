import pandas as pd

from sklearn.linear_model import Ridge
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score


X_train = pd.read_csv("data/X_train.csv")

X_test = pd.read_csv("data/X_test.csv")

y_train = pd.read_csv("data/y_train.csv").squeeze()

y_test = pd.read_csv("data/y_test.csv").squeeze()

model = Ridge(alpha=1.0)

model.fit(X_train, y_train)

prediction = model.predict(X_test)

mae = mean_absolute_error(
    y_test,
    prediction
)

rmse = mean_squared_error(
    y_test,
    prediction
) ** 0.5

r2 = r2_score(
    y_test,
    prediction
)

print("Ridge Regression Results")

print("MAE:", mae)
print("RMSE:", rmse)
print("R2:", r2)


#Ridge Model 


import pandas as pd

from sklearn.linear_model import Ridge

from sklearn.metrics import (
    mean_absolute_error,
    mean_squared_error,
    r2_score
)


X_train = pd.read_csv(
    "data/X_train.csv"
)

X_test = pd.read_csv(
    "data/X_test.csv"
)

y_train = pd.read_csv(
    "data/y_train.csv"
).squeeze()

y_test = pd.read_csv(
    "data/y_test.csv"
).squeeze()


model = Ridge(
    alpha=1.0
)


model.fit(
    X_train,
    y_train
)


prediction = model.predict(
    X_test
)


mae = mean_absolute_error(
    y_test,
    prediction
)


rmse = (
    mean_squared_error(
        y_test,
        prediction
    ) ** 0.5
)


r2 = r2_score(
    y_test,
    prediction
)


print(
    "Final Ridge Regression Results"
)

print(
    "MAE:",
    mae
)

print(
    "RMSE:",
    rmse
)

print(
    "R2:",
    r2
)
# ACTUAL VS PREDICTED


comparison = pd.DataFrame({

    "Actual": y_test.values,

    "Predicted": prediction

})


print(
    comparison.head(10)
)