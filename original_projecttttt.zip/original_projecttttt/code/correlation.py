import pandas as pd 
import matplotlib.pyplot as plt

df = pd.read_csv(
    "data/HDFCBANK_features.csv"
)

numeric_df = df.select_dtypes(
    include="number"
)

correlation = numeric_df.corr()["Target"].sort_values(
    ascending=False
)

print("Correlation with Target:")
print(correlation)