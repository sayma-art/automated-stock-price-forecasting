import  pandas as pd

from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor

x_train = pd.read_csv("data/X_train.csv") 
y_train = pd.read_csv("data/y_train.csv").squeeze()

print("x_train.shape:", x_train.shape)
print("y_train.shape:", y_train.shape)
#ML model
linear_model = LinearRegression()
linear_model.fit(
    x_train,
    y_train
)

#RF
rf_model = RandomForestRegressor(
    n_estimators=100,
    random_state=42,
    n_jobs=-1
)
rf_model.fit(
    x_train,
    y_train
)

#Prediction
linear_prediction = linear_model.predict(
    x_train
)
rf_prediction = rf_model.predict(
    x_train
)
print(linear_prediction[:5])
print(rf_prediction[:5])