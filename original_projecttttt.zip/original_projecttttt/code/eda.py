import pandas as pd
import matplotlib.pyplot as plt
df = pd.read_csv("data/HDFCBANK_clean.csv")
#converting date into datetimed
plt.figure(figsize=(12,6))
plt.plot(df["Date"],df["Close"])
plt.title("HDFC Bank Closing Price")
plt.xlabel("Date")
plt.ylabel("Price")
plt.show()

#open Vs close
plt.figure(figsize=(12,6))
plt.plot(df["Date"],df["Open"],label="Open")
plt.plot(df["Date"],df["Close"],label="Close")
plt.title("HDFC Bank Open Vs Close")
plt.xlabel("Date")
plt.ylabel("Price")
plt.legend()
plt.show()

#high Vs low
plt.figure(figsize=(12,6))
plt.plot(df["Date"],df["High"],label="High")
plt.plot(df["Date"],df["Low"],label="Low")
plt.title("HDFC Bank High vs Low")
plt.xlabel("Date")
plt.ylabel("price")
plt.legend()
plt.show()

#volume Graph
plt.figure(figsize=(12,6))
plt.plot(df["Date"],df["Volume"])
plt.title("HDFC Bank Trading Volume")
plt.xlabel("Date")
plt.ylabel("Volume")
plt.show()


#distribution of closing price
plt.figure(figsize=(10,6))
plt.hist(df["Close"],bins=50)
plt.title("Distribution of HDFC Bank Closing Price")
plt.xlabel("Closing Price")
plt.ylabel("Frequency")       
plt.show()         

#Boxplot 
plt.figure(figsize=(8,6))
plt.boxplot(df["Close"])
plt.title("Closing Price Boxplot")
plt.ylabel("Closing Price")
plt.show()

#Daily Return
df["Daily Return"]=df["Close"]

plt.figure(figsize=(12,6))
plt.plot(df["Date"],df["Daily Return"])
plt.title("HDFC Bank Daily Return")
plt.xlabel("Date")
plt.ylabel("Daily Return")
plt.show()

# Distribution of Return
plt.figure(figsize=(10,6))
plt.hist(df["Daily Return"].dropna(),bins=50)
plt.title("HDFC Bank Dist of return")
plt.xlabel("Daily Return")
plt.ylabel("Frequency")
plt.show()

#Correlation
print(df[[
    "Open",
    "High",
    "Low",
    "Close",
    "Volume"
]].corr())

#Heatmap
import seaborn as sns
correlation = df[
    ["Open", "High", "Low", "Close", "Volume"]
].corr()
plt.figure(figsize=(8,6))
sns.heatmap(
    correlation,
    annot=True
)
plt.title("HDFC Bank Correlation Matrix")
plt.show()

df.to_csv("data/HDFC_eda.csv",
          index=False)