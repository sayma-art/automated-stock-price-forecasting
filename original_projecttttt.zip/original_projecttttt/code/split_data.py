import pandas as pd
df = pd.read_csv("data/HDFCBANK_features.csv")

df["Date"] = pd.to_datetime(df["Date"])
# CREATE X AND y
# Target = tomorrow's closing price
y = df["Target"]

# Features
X = df.drop(columns=["Target", "Date"])
# TRAIN / TEST SPLIT

split_index = int(len(df) * 0.80)

X_train = X.iloc[:split_index]
X_test = X.iloc[split_index:]

y_train = y.iloc[:split_index]
y_test = y.iloc[split_index:]

#  CHECK DATA

print("Total rows:", len(df))
print("Split index:", split_index)

print("y shape:", y.shape)

print("Testing X:", X_test.shape)

print("Testing y:", y_test.shape)

#  CHECK DATES

print(df["Date"].iloc[0])
print(df["Date"].iloc[split_index - 1])
print(df["Date"].iloc[split_index])
print(df["Date"].iloc[-1])

#save
X_train.to_csv("data/X_train.csv", index=False)
X_test.to_csv("data/X_test.csv", index=False)

y_train.to_csv("data/y_train.csv", index=False)
y_test.to_csv("data/y_test.csv", index=False)

