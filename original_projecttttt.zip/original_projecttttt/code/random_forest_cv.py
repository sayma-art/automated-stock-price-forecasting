import pandas as pd

from sklearn.model_selection import TimeSeriesSplit
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error



df = pd.read_csv(
    "data/HDFCBANK_features.csv"
)


X = df.drop(
    columns=["Target", "Date"]
)

y = df["Target"]



tscv = TimeSeriesSplit(
    n_splits=5
)


mae_scores = []


for fold, (train_index, test_index) in enumerate(
    tscv.split(X),
    start=1
):

    X_train = X.iloc[train_index]
    X_test = X.iloc[test_index]

    y_train = y.iloc[train_index]
    y_test = y.iloc[test_index]


    model = RandomForestRegressor(
        n_estimators=200,
        max_depth=10,
        random_state=42,
        n_jobs=-1
    )


    model.fit(
        X_train,
        y_train
    )


    prediction = model.predict(
        X_test
    )


    mae = mean_absolute_error(
        y_test,
        prediction
    )


    mae_scores.append(
        mae
    )


    print(
        f"Fold {fold} MAE: {mae}"
    )


average_mae = sum(
    mae_scores
) / len(
    mae_scores
)


print("\nMAE scores:")
print(mae_scores)

print("\nAverage MAE:")
print(average_mae)

print(df.columns.tolist())
print(df.head())
print(df["Target"].describe())