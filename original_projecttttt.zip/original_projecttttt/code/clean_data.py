import pandas as pd
df = pd.read_csv("data/HDFCBANK_raw.csv",
                 header = [0,1],
                 index_col = 0,
                 )
df.columns = df.columns.get_level_values(0)
df.index = pd.to_datetime(df.index)
df = df.reset_index()
df = df[
    ["Date",
     "Open",
     "High",
     "Low",
     "Close",
     "Adj Close",
     "Volume"
    

    ]
]
df = df.sort_values("Date")  
print(df.head())
print(df.shape)
print(df.describe())
print(df.isnull().sum())
print(df.duplicated().sum())
print(df["Date"].min(),"to",df["Date"].max())
print(df.info())

print((df[["Open","High","Low","Close"]]).sum())
print((df["High"]<df["Open"]).sum())
print((df["High"]<df["Close"]).sum())
print((df["Low"]>df["Open"]).sum())
print((df["Low"]>df["Close"]).sum())
#checking volume
print((df["Volume"]<0).sum())
#date order
print(df["Date"].is_monotonic_increasing)
df.to_csv("data/HDFCBANK_clean.csv",index=False)